# 如何使用Gitea

## 参考文献

[1] [【狂神说Java】Git最新教程通俗易懂_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1FE411P7B3?p=11)

## Gitea界面

### 登录

[Gitea: Git with a cup of tea](http://172.27.66.249:10003/)

```
校园网登录:http://172.27.66.249:10003/
gitea Web服务器端口:10003
gitea SSH服务器端口:10002
```

```
初始用户名:姓名全拼,字母小写
初始密码:123456
```

### 新建仓库

![image-20210908034412364](如何使用gitea.assets/image-20210908034412364.png)

新建仓库后,可以通过git命令上传下载修改自己的代码.**建议尽量创建公开仓库,促进相互交流**

### 新建组织

![image-20210908034745692](如何使用gitea.assets/image-20210908034745692.png)

通过组织成员可以实现查看成员的主页,浏览成员的仓库,学习成员的代码和笔记等多种功能.

通过组织团队,可以创建任务,通过团队合作完成任务.

![image-20210908035932491](如何使用gitea.assets/image-20210908035932491.png)

### 合并请求

比如别人找到你仓库中的代码有一些bug,他把你的代码pull到本地做了修改.然后提出合并请求,希望你能采纳建议.你有权采纳或者拒绝.

![image-20210908041222010](如何使用gitea.assets/image-20210908041222010.png)在github中此为 Pull Requests

![image-20210908041155169](如何使用gitea.assets/image-20210908041155169.png)

### 工单及工单管理

工单可以理解成一个小贴吧,小论坛.可以向作者询问问题,做出评论,也可以和其他成员探讨问题.可以在此发送图片,链接等多种文件类型

![image-20210908041827395](如何使用gitea.assets/image-20210908041827395.png)

类似于github中的issues

![image-20210908042140380](如何使用gitea.assets/image-20210908042140380.png)

## Git学习

可以通过文献[1]快速学习git指令. 跟着一步步做,可速成

主要掌握如何让自己的电脑和gitea建立通信.学会通过http或者ssh形式下载上传修改文件.

### 基本命令

```shell
git clone [url] 			#克隆(下载)文件
git add .					#添加需要上传的文件
git commit -m "自己的描述"	 #提交
git push					#上传
```

### SSH

如果使用SSH传输,需要在`用户`文件下的`.ssh`创建 密钥对,并将公钥放入如下图所示位置.

```cmd
ssh-keygen -t rsa -C "your_email@example.com" 
#注意我初始邮箱设置为姓名首字母形式@gitea.com,具体请登录后查看自己的邮箱(邮箱可修改)
```

密钥和自己的电脑唯一绑定,换电脑后需在添加一个公钥.

![image-20210908052104387](如何使用gitea.assets/image-20210908052104387.png)

### Git图示

![R-C](如何使用gitea.assets/R-C.png)



小提醒

> SSH 传输文件,在push的时候可以不用输入密码.但是如果您以前使用过SSH用于github或者gitee,要注意公钥是不同意的.而且您需要在用户.gitconfig中做出修改.
>
> 详细请百度搜索 配置github gitee共存的git环境  等类似的语句

