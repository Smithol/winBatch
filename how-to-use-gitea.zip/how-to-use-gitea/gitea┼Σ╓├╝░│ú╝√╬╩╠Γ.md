# gitea配置及常见问题

## 参考文献

[1] [Installation with Docker - Docs (gitea.io)](https://docs.gitea.io/en-us/install-with-docker/)

## 使用docker-compose 搭建gitea环境

docker-compose.yml

```dockerfile
version: "3"

networks:
  gitea:
    external: false

services:
  server:
    image: gitea/gitea:1
    container_name: gitea
    environment:
      - USER_UID=1000
      - USER_GID=1000
      - DB_TYPE=mysql
      - DB_HOST=db:3306
      - DB_NAME=gitea123
      - DB_USER=gitea123
      - DB_PASSWD=gitea123
    restart: always
    networks:
      - gitea
    volumes:
      - ./gitea:/data
      - /etc/timezone:/etc/timezone:ro
      - /etc/localtime:/etc/localtime:ro
    ports:
      - "10003:3000"
      - "10002:22"
    depends_on:
      - db
 
  db:
    image: mysql:8
    container_name: gitea_mnt_mysql
    security_opt:
      - seccomp=unconfined
    restart: always
    environment:
      - MYSQL_ROOT_PASSWORD=gitea123
      - MYSQL_USER=gitea123
      - MYSQL_PASSWORD=gitea123
      - MYSQL_DATABASE=gitea123
    networks:
      - gitea
    volumes:
      - ./mysql:/var/lib/mysql
```

gitea程序位于421服务器home421用户中,文件位置`/home/home421/gitea_mysql`.

## 配置常见问题

### 无法使用ssh

启动容器后会设置信息,注意此时要把localhost换成服务器的ip.部分端口应换成映射端口

![image-20210908045539342](gitea配置及常见问题.assets/image-20210908045539342.png)

配置失误,可通过修改配置文件`/home/home421/gitea_mysql/gitea/gitea/conf/app.ini`来修正.修正后配置文件部分截图.

![image-20210908020345948](gitea配置及常见问题.assets/image-20210908020345948.png)

### 数据库拒绝访问

`docker-compose.yml`加入

```shell
 security_opt:
      - seccomp=unconfined
```

### docker命令权限问题

最好把`home421`加入到`docker`组中,这样就不用每次都`sudo`去获得`root`权限.

```shell
sudo usermod -a -G docker home421 
#使用 cat /etc/group | grep docker 查看是否成功
#显示为	docker:x:998:home421   成功.
```

### dockerhub不要登录

有时候我们需要去dockerhub中查看dockerfile,注意不要去登录自己的账号,如果登录容易出现404拒绝访问的界面.

如果出现404拒绝访问,就删除相应`Cookie`

![image-20210908053045232](gitea配置及常见问题.assets/image-20210908053045232.png)

### 英语能力不足

这虽然是国人仿照gitlab 而写的一个开源项目,但是文档还是以英语为主.平时注意提高英语能力,不然很难受的.

![image-20210908053227196](gitea配置及常见问题.assets/image-20210908053227196.png)