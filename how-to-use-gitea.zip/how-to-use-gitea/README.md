# how-to-use-gitea

更新一些gitea的使用技巧